**Xelatex** wird als **ENGINE** für das Generieren von PDF-Dateien mit Pandoc
verwendet.  

Dafür ist die Installation von **MiKTeX** erforderlich.  


xelatex.exe liegt im Verzeichnis:   

```
C:\Program Files\MiKTeX\miktex\bin\x64\xelatex.exe
```

nach der Installation von MiKTeX muß xelatex.exe registriert und eine PATH-Variable
angelegt werden.  
Dafür dient die reg-Datei.